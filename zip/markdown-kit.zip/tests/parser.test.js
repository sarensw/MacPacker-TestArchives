import assert from 'node:assert/strict'
import { test } from 'node:test'

import { render, renderInline, tokenize } from '../src/index.js'

test('headings carry their level', () => {
  assert.deepEqual(tokenize('### Title'), [{ type: 'heading', level: 3, text: 'Title' }])
  assert.equal(render('# Hello'), '<h1>Hello</h1>')
})

test('consecutive lines join into one paragraph', () => {
  assert.equal(render('one\ntwo'), '<p>one two</p>')
  assert.equal(render('one\n\ntwo'), '<p>one</p>\n<p>two</p>')
})

test('fenced code keeps its language and is not re-parsed', () => {
  const [token] = tokenize('```js\nconst a = **1**\n```')
  assert.equal(token.type, 'code')
  assert.equal(token.language, 'js')
  assert.equal(token.text, 'const a = **1**')
  assert.match(render('```js\na < b\n```'), /<code class="language-js">a &lt; b<\/code>/)
})

test('an unterminated fence runs to the end of the input', () => {
  assert.deepEqual(tokenize('```\nstill open'), [
    { type: 'code', language: null, text: 'still open' },
  ])
})

test('adjacent bullets collapse into one list', () => {
  assert.equal(render('- one\n- two'), '<ul><li>one</li><li>two</li></ul>')
})

test('inline forms nest inside blocks', () => {
  assert.equal(renderInline('**bold** and *italic*'), '<strong>bold</strong> and <em>italic</em>')
  assert.equal(renderInline('[docs](https://example.com)'), '<a href="https://example.com">docs</a>')
})

test('code spans are not scanned for emphasis', () => {
  assert.equal(renderInline('`**verbatim**`'), '<code>**verbatim**</code>')
})

test('markup in the input is escaped', () => {
  assert.equal(render('<script>alert(1)</script>'), '<p>&lt;script&gt;alert(1)&lt;/script&gt;</p>')
})

test('blockquotes drop the marker', () => {
  assert.equal(render('> quoted'), '<blockquote>quoted</blockquote>')
})

test('CRLF input is normalised', () => {
  assert.equal(render('one\r\n\r\ntwo'), '<p>one</p>\n<p>two</p>')
})
