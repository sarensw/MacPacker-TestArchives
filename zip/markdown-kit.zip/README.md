# markdown-kit

A tiny Markdown renderer with no runtime dependencies. One function in, HTML
out — about 200 lines, no plugin system, no configuration object.

It covers the subset of Markdown that documentation actually uses: headings,
paragraphs, fenced code, blockquotes, lists, and the four inline forms. If you
need tables, footnotes or MDX, use a full CommonMark implementation instead.

## Install

```sh
npm install markdown-kit
```

## Usage

```js
import { render } from 'markdown-kit'

render('# Hello\n\nSome **bold** text.')
// => '<h1>Hello</h1>\n<p>Some <strong>bold</strong> text.</p>'
```

Everything is escaped by default, so rendering untrusted input does not inject
markup:

```js
render('<script>alert(1)</script>')
// => '<p>&lt;script&gt;alert(1)&lt;/script&gt;</p>'
```

## API

### `render(markdown)`

Renders a Markdown string to an HTML string.

### `tokenize(markdown)`

Returns the intermediate block tokens, if you would rather emit something other
than HTML. Each token is `{ type, ... }`, where `type` is one of `heading`,
`paragraph`, `code`, `quote` or `list`.

## Supported syntax

| Block        | Written as                    |
| ------------ | ----------------------------- |
| Heading      | `# Title` through `###### h6` |
| Code         | ` ```js ` fenced              |
| Quote        | `> quoted`                    |
| List         | `- item` or `* item`          |
| Paragraph    | anything else                 |

Inline: `**bold**`, `*italic*`, `` `code` `` and `[text](url)`.

## Development

```sh
npm install
npm test        # node --test
npm run build   # bundles to dist/
```

## License

MIT — see [LICENSE](LICENSE).
