// Block-level scanner. Line based, single pass, no lookbehind: every block
// either opens on its own first line or is a paragraph.

const HEADING = /^(#{1,6})\s+(.*)$/
const FENCE = /^```(\w*)\s*$/
const QUOTE = /^>\s?(.*)$/
const BULLET = /^[-*]\s+(.*)$/

/**
 * Splits Markdown into block tokens.
 *
 * Returns an array of `{ type, ... }`:
 *   { type: 'heading',   level, text }
 *   { type: 'code',      language, text }
 *   { type: 'quote',     text }
 *   { type: 'list',      items }
 *   { type: 'paragraph', text }
 */
export function tokenize(markdown) {
  const lines = String(markdown).replace(/\r\n?/g, '\n').split('\n')
  const tokens = []
  let paragraph = []

  // Paragraphs run until a blank line or a block that opens on its own, so
  // every branch below has to close the one being collected first.
  const flush = () => {
    if (paragraph.length) {
      tokens.push({ type: 'paragraph', text: paragraph.join(' ').trim() })
      paragraph = []
    }
  }

  for (let index = 0; index < lines.length; index++) {
    const line = lines[index]

    const fence = FENCE.exec(line)
    if (fence) {
      flush()
      const body = []
      // Consume through the closing fence; an unterminated fence runs to the
      // end of the input rather than throwing.
      while (++index < lines.length && !FENCE.test(lines[index])) {
        body.push(lines[index])
      }
      tokens.push({ type: 'code', language: fence[1] || null, text: body.join('\n') })
      continue
    }

    if (!line.trim()) {
      flush()
      continue
    }

    const heading = HEADING.exec(line)
    if (heading) {
      flush()
      tokens.push({ type: 'heading', level: heading[1].length, text: heading[2].trim() })
      continue
    }

    const quote = QUOTE.exec(line)
    if (quote) {
      flush()
      tokens.push({ type: 'quote', text: quote[1].trim() })
      continue
    }

    const bullet = BULLET.exec(line)
    if (bullet) {
      flush()
      const items = [bullet[1].trim()]
      // Adjacent bullets are one list.
      while (index + 1 < lines.length && BULLET.test(lines[index + 1])) {
        items.push(BULLET.exec(lines[++index])[1].trim())
      }
      tokens.push({ type: 'list', items })
      continue
    }

    paragraph.push(line.trim())
  }

  flush()
  return tokens
}
