// markdown-kit — the whole public surface.

import { tokenize } from './parser.js'

export { tokenize }

const ESCAPES = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }

/** Escapes the characters that would otherwise be read as markup. */
export function escapeHtml(text) {
  return text.replace(/[&<>"]/g, (character) => ESCAPES[character])
}

const PLACEHOLDER = /\u0000(\d+)\u0000/g

/**
 * Renders inline Markdown: links, then the two emphasis forms.
 *
 * Code spans are lifted out into placeholders first and put back last. Running
 * their replacement inline would not be enough — the later emphasis passes walk
 * the whole string, so `` `**verbatim**` `` would come back emphasised.
 */
export function renderInline(text) {
  const spans = []
  const withPlaceholders = escapeHtml(text).replace(/`([^`]+)`/g, (_, code) => {
    spans.push(code)
    return `\u0000${spans.length - 1}\u0000`
  })
  return withPlaceholders
    .replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, '<a href="$2">$1</a>')
    .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
    .replace(/\*([^*]+)\*/g, '<em>$1</em>')
    .replace(PLACEHOLDER, (_, index) => `<code>${spans[index]}</code>`)
}

function renderToken(token) {
  switch (token.type) {
    case 'heading':
      return `<h${token.level}>${renderInline(token.text)}</h${token.level}>`
    case 'code':
      // Code is escaped but never rendered as inline Markdown.
      return token.language
        ? `<pre><code class="language-${token.language}">${escapeHtml(token.text)}</code></pre>`
        : `<pre><code>${escapeHtml(token.text)}</code></pre>`
    case 'quote':
      return `<blockquote>${renderInline(token.text)}</blockquote>`
    case 'list':
      return `<ul>${token.items.map((item) => `<li>${renderInline(item)}</li>`).join('')}</ul>`
    default:
      return `<p>${renderInline(token.text)}</p>`
  }
}

/** Renders a Markdown string to HTML. */
export function render(markdown) {
  return tokenize(markdown).map(renderToken).join('\n')
}

export default render
