A file anyone can see.
