This file is stored, and is checked like any other.
